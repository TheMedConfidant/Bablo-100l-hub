# Bablo 100L Hub

Quiz platform for Bowen CoHES 100L students. One file: `dist/index.html`.

## Use
Open the file in any browser, or open the published link. Works offline after the first load.

## Rebuild
```
node build.js        # src/ + data/questions.json -> dist/index.html and data/bank.compact.json
node test/run.js     # engine and data tests
NODE_PATH=<jsdom>/node_modules node test/ui-smoke.js   # end-to-end UI test
```

## Add a course or question bank
1. Add a line to `COURSES` in `src/content.js` (`code` must match the bank's subject code).
2. Put the extracted questions in `data/raw/` and run `node tools_extract.js` to merge them into `data/questions.json`.
3. Run `node build.js`, then the tests. Course tiles switch from Pending to Available automatically once questions exist.

## Turn on the global leaderboard
1. Create a Supabase project and run `supabase_setup.sql`.
2. Set `LB.url` and `LB.key` (publishable key) in `src/content.js`, then rebuild.
Until then the leaderboard runs on each device only.

## Social Corner and feedback
- Social posts go to `social_posts` (public read and post, 500 characters, plain text). Students can report a post, which lands in `feedback` with kind `report_post`.
- Feedback from the Me page goes to `feedback` (insert only, nobody can read it from the app).
- To read reports or feedback: Supabase dashboard, Table Editor, open `feedback`. Remove abusive posts from `social_posts` in the same place.
- Public posting can attract spam. Before a large launch, add rate limits (Supabase edge function or a rule in the database) and a moderator routine.

## Sources in this build
- BIO, PHY, CHM, COS, AGR: lecture quizzes uploaded earlier.
- GEL 101: the 2019/2020 exam key (about 210 questions) plus a Lean on Me set. Film items are flagged.
- GST 111: a GST 101 past-question file (99 fill-in items). The file is titled GST 101 but the content is Communication in English. Confirm the course code.
- GST 103 and Library 101 are not in this build (next semester).

## Programme Cup
- Settings are in `src/content.js`: `EVENT_WINDOWS` (times, Lagos time), `SEASON` (start date and weeks), `COURSE_WEIGHTS` (equal by default), and `CUP` (minimum players, top N).
- Only timed quizzes and exams taken inside a window count, and each student's best score per course counts.
- Guests (other programmes) are grouped under 'Guests' and never ranked against CoHES programmes.
- Change `SEASON.start` each season and rebuild.

## Weak spots and chess
- Weak spots: each answered question records right and wrong counts in the device data (`DB.stats`). Topics with 3+ answers and under 70% show on the Weak spots page, with practice buttons.
- Chess: `src/chess.js` has the full rules. Its move generator is checked against standard perft counts (start position to depth 3 and Kiwipete to depth 2). The computer has three levels.

## Chess
- Settings: game type (friendly or ranked), computer level (matches you, easy, medium, hard), play as white, black or random, and a clock (off, 3, 5 or 10 minutes a side).
- Friendly games allow take-backs and never change the rating. Ranked games have no take-backs, and the rating moves after each game.
- Online challenges: create a challenge (share the 6-letter code), join with a code, or join from the open challenges list. Moves sync by polling every 2.5 seconds. Online games have no clock or take-backs yet, and they update win/draw/loss records but not the rating.
- Known limit: the database rules let anyone change a game row, so online games can be tampered with.

## Looks
- Look toggle on the Me page: Glass (default), Green or Classic. Light or dark is separate.

## Feedback that updates the app
- Each reviewed question has a Report button. After 3 reports, the question is hidden from quizzes and exams for everyone. No rebuild needed. Practice still shows it, with a warning if it is flagged.
- Reports are counted in `question_reports`. Reading or changing the threshold: `loadHidden` in `src/ui3.js`.
- Feedback and reports are summarised in the `feedback_digest` view. Ask the assistant for a digest and it reads and triages everything in one go.

## Corrections (verified from multiple sources)
- Students use Suggest a correction on a reviewed question, giving the answer they think is right and where they checked it.
- Suggestions are stored as pending. Nothing changes for students until a suggestion is marked verified in `question_corrections`.
- Verify only when at least two independent sources agree (book, lecture notes, official past paper, or a reputable site). Record the sources and set status to verified.
- Verified corrections are applied on the next app load, without a rebuild. The correct answer must match one of the existing options.

## Win popup
- When a game ends (computer or online), a popup names the winner and returns you to the chess dashboard. The chess menu shows the last result.

## Sources in this build (update)
- BIO 101 Biology questions (Word, read from Drive): 31 items, all flagged because the source has no answer key. Practice only until verified.
- A COS holiday-assignment Word file was read but not loaded: it is a completed student assignment with no key and personal details.

## Content notes
- Answer keys come from the original lecture quizzes and are not independently verified.
- Questions marked FLAGGED in `data/questions.json` are excluded from timed quizzes and exams.
- Chemistry configurations render as superscripts.
- Verses are from the King James Version (public domain).
- Praise and roast lines by programme come from `src/feedback_pool.js`. Nutrition and Biochemistry use the 'Other CoHES programme' lines until they have their own.
